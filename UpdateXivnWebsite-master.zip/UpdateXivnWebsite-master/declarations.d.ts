// declarations.d.ts

declare module '*.yml' {
    const value: any;
    export default value;
  }
  